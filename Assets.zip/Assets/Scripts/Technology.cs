﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Technology : Property {
    
	public Technology(string name, Sprite icon, float developTime) : base(name, icon, developTime) { }

}
