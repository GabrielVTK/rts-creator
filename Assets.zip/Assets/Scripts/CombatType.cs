﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CombatType {

	private string name;
	private List<CombatType> offensiveAdvantages;
	private List<CombatType> offensiveDisadvantages;

	public CombatType() {}

}
