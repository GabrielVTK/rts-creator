﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollectMaterialOrder : Order {

    public override bool Cooldown() {
        throw new NotImplementedException();
    }

    public override void Execute() {
        throw new NotImplementedException();
    }

}
